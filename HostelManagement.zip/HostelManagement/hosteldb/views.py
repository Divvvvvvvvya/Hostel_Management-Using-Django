from typing import Counter
from django.http.response import HttpResponseGone
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template.response import TemplateResponse
from django.urls import reverse
from hosteldb.models import *

# Create your views here.
def index(request):
    return TemplateResponse( request,"index.html")

def insertdb(request):
    if request.method == "GET":
        return TemplateResponse(request, "insertdb.html", context={})
    if request.method == "POST":
        sano = request.POST.get("ano", None)
        sname = request.POST.get("name", None)
        sage = request.POST.get("age", None)
        sadd = request.POST.get("address", None)
        snat= request.POST.get("native", None)
        smno= request.POST.get("mno", None)
        if len(smno)<10 :
            return TemplateResponse(request, "index.html",context = { 'status' : 'Please Enter a Valid 10 digit Mobile Number' })

        h1 = HostelDeets(Aadharno = sano, Name = sname, Age = sage, Address = sadd, Native = snat, Mobile = smno)
        h1.save()
        return TemplateResponse(request, "index.html",context = { 'status' : 'Entry Added' })


def viewdb(request):
    data = HostelDeets.objects.all()
    #g1 = Grocery.objects.get(Name="coconut")
    #g1.delete()
    # g2 = Grocery.objects.get(id="2")
    # g2.delete()
    return TemplateResponse(request , "outputtable.html" , context = { "hostdeets" : data})

def searchdb(request):
    if request.method == "GET":
        return TemplateResponse(request, "searchpage.html", context={})
    if request.method == "POST":
        smno= request.POST.get("searchmno", None)
        try:
             data = HostelDeets.objects.get(Mobile=smno)
        except:
            return TemplateResponse(request, "index.html",context = { 'status' : 'Entry not present. Please try with a valid entry' })

        #g1 = Grocery.objects.get(Name="coconut")
        #g1.delete()
        # g2 = Grocery.objects.get(id="2")
        # g2.delete()
        return TemplateResponse(request , "outputsearch.html" , context = { "hostdeets" : data})


   