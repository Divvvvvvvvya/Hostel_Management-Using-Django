from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index , name="index"),
    path('viewdb', views.viewdb , name="viewdatabase"),
    path('insertdb', views.insertdb , name="insertdatabase"),
    path('searchdb', views.searchdb , name="searchdatabase")

]
