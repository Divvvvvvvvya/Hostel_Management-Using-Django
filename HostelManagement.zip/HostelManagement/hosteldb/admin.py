from django.contrib import admin
from .models import HostelDeets

@admin.register(HostelDeets)
class Hosteladmin(admin.ModelAdmin):
    #list_filter = ('Type',)
    #ordering = ('VitaminPresent','-Name')
    list_display=['Aadharno','Name','Age','Address','Native','Mobile']
    #search_fields = ('Name',)
