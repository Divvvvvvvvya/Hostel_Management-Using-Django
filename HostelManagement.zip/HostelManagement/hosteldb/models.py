
from django.db import models

# Create your models here.
class HostelDeets(models.Model):
    Aadharno = models.TextField(default=0)
    Name = models.CharField(max_length=120)
    Age = models.IntegerField(default=0)
    Address = models.TextField(default=0)
    Native = models.CharField(max_length=120)
    Mobile = models.TextField(default=0)
    
   